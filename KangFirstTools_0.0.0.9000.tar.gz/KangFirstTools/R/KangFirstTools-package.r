#' KangFirstTools.
#'
#' @name KangFirstTools
#' @docType package
NULL
