
           #' This is data which is included in package, KangHanGyutools
           #'
           #' @author HanGyu Kang \email{kangx478@umn.edu}
           #' @reference \url{http://users.stat.umn.edu/~almquist/3811_examples/gapminder2007ex.csv}
           "d" 