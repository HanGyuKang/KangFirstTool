library(testthat)
library(KangFirstTools)

test_check("KangFirstTools")
