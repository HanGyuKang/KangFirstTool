library(testthat)
library(KangSecondTools)

test_check("KangSecondTools")
