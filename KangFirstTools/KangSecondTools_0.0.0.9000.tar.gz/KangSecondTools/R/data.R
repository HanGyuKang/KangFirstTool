
           #' This is third data which is included in package, KangHanGyutools
           #' 
           #' @author HanGyu Kang \email{kangx478@umn.edu}
           #' @reference \url{http://www.stat.umn.edu/geyer/3701/data/array-ex1.csv}
           "d" 